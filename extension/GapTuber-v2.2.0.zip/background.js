try {
  if (chrome.sidePanel) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
} catch (err) {
  console.error("[GapTuber] Failed to configure side panel behavior:", err);
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    const isChannelPage = /youtube\.com\/(@|channel\/|c\/|user\/)/i.test(changeInfo.url);
    if (isChannelPage) {
      chrome.sidePanel.open({ windowId: tab.windowId }).catch((err) => console.error("[GapTuber] Failed to auto-open side panel:", err));
    }
  }
});
